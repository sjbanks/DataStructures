
/** driver file to test the link queue class
 * @author Steven Banks
 *
 */
public class LinkQueueDriver {

	public static void main(String[] args) {
		//Create 10 strings of names from Battlestar Galactica
		String kara = "Kara Thrace: Staruck";
		String karl = "Karl Agathon: Helo";
		String sharon = "Sharon Agathon: Athena (Boomer)";
		String lee = "Lee Adama: Apollo";
		String louanne = "Louanne Katraine: Kat";
		String margaret = "Margaret Edmondson: Racetrack";
		String sam = "Samuel Anders: Longshot";
		String william = "Admiral William Adama";
		String saul = "Colonel Saul Tigh";
		String laura = "President Laura Roslin";
		
		//create a new queue and add some names
		Queue bsgQueue = new Queue();
		bsgQueue.enqueue(kara);
		bsgQueue.enqueue(karl);
		bsgQueue.enqueue(sharon);
		bsgQueue.enqueue(lee);
		bsgQueue.enqueue(louanne);
		bsgQueue.queueSize(); //should be five links
		bsgQueue.printQueue(); //should print 5 values
		bsgQueue.peek(); //should show starbuck
		System.out.print("--------------------------------------\n");	//just trying to make it easier to read
		
		bsgQueue.dequeue(); //should remove starbuck
		bsgQueue.dequeue(); //should remove helo
		bsgQueue.queueSize(); //should be 3
		bsgQueue.peek(); //should be sharon
		bsgQueue.printQueue(); //should just be sharon, apollo and kat
		System.out.print("--------------------------------------\n");	//just trying to make it easier to read
		
		bsgQueue.enqueue(kara);
		bsgQueue.enqueue(karl);
		bsgQueue.enqueue(margaret);
		bsgQueue.enqueue(sam);
		bsgQueue.enqueue(william);
		bsgQueue.enqueue(saul);
		bsgQueue.enqueue(laura);
		bsgQueue.peek(); //should still be sharon
		bsgQueue.printQueue(); //should be all 10 strings
		bsgQueue.queueSize(); //should print there are 10 links
		System.out.print("--------------------------------------\n");	//just trying to make it easier to read
		
		bsgQueue.dequeue(); //should remove sharon first
		bsgQueue.dequeue();	//lee
		bsgQueue.dequeue(); //kat
		bsgQueue.dequeue(); //kara
		bsgQueue.dequeue(); //karl
		bsgQueue.dequeue(); //racetrack
		bsgQueue.dequeue(); //sam
		bsgQueue.dequeue(); //bill
		bsgQueue.dequeue(); //saul
		bsgQueue.dequeue(); //laura
		bsgQueue.dequeue(); //should now print that the queue is empty
		bsgQueue.queueSize(); //should print 0
		System.out.print("--------------------------------------\n");	//just trying to make it easier to read
		
		//just to test a few more values, I'll create a couple more strings and add to the same queue
		String six = "Caprica Six: Tall Blonde, Slinky Red Dress";
		String traitor = "Gaius Baltar: Slimeball";
		String eight = "Sharon Valeri: What in the world is going on in this universe?";
		String three = "Xena: Warrior Princess";
		String two = "Creepy Pastor Guy";
		bsgQueue.enqueue(six);
		bsgQueue.enqueue(traitor);
		bsgQueue.enqueue(eight);
		bsgQueue.enqueue(three);
		bsgQueue.enqueue(two);
		bsgQueue.peek(); //should be six
		bsgQueue.printQueue(); 
		bsgQueue.queueSize(); //should again be 5
		bsgQueue.dequeue(); //six
		bsgQueue.dequeue(); //gaius
		bsgQueue.dequeue(); //eight
		bsgQueue.dequeue(); //three
		bsgQueue.dequeue(); //two
		//queue should again be empty
		bsgQueue.dequeue(); //should display message that it's empty
		
		//I like this way better than having to deal with wraparound
	}

}
