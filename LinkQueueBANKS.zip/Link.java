/**This class creates links for the linkqueue
 * @author Steven Banks
 *
 */
public class Link {

	//declare variables 
	public String name;
	public Link next;
	
	/**
	 * @param name accepts a user-created string
	 */
	public Link(String name) {
		this.name = name;	//set the global variable to the argument passed in
	}
	
	/**
	 * @return	the value of the next link
	 */
	public Link getNext() {
		return next;
	}
	/**
	 * @param next allows you to manually set the value of the next link
	 */
	public void setNext(Link next) {
		this.next = next;
	}

	/**
	 * displays the string value of the link
	 */
	public void displayLink() {
		System.out.println(name);
	}
}