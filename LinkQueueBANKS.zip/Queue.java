
/**This class creates the link queue and it's methods
 * @author Steven Banks
 *
 */
public class Queue {

	private Link first;	//variable for the first value in the queue
	private int size; //will keep track of how many links are in the queue
	
	/**
	 * uses a private method to instantiate a new queue
	 */
	public Queue() {
		setQueue();
	}
	
	/**
	 * @return true if the queue is empty
	 */
	public boolean isEmpty() {
		return (first == null);
	}
	/**
	 * @param name takes a user-created string and uses a private method to add it to the end of the queue
	 */
	public void enqueue(String name) {
		add(name);
	}
	/** removes the first string in the queue
	 * @return the removed string using a private method
	 */
	public Link dequeue() {
		return remove();
	}
	/**
	 *  uses a private method to peek at the first value in the queue
	 */
	public void peek() {
		lookylooky();
	}
	/**
	 * uses a private method to print all the values in the queue
	 */
	public void printQueue() {
		display();
	}
	/**
	 * uses a private method to print how many values are in the queue
	 */
	public void queueSize() {
		size();
	}
	
	/**
	 * sets the default values for a new queue, called by the public method
	 */
	private void setQueue() {
		first = null;
		size = 0;
	}
	/** called by the public method enqueue() to add a new string to the end of a queue
	 * @param name takes the user-created string
	 */
	private void add(String name) {
		if (!isEmpty()) {
			Link newName = new Link(name); // create a new link with user string
			Link current = first; // a pointer to move through the list so far
			while (current.next != null) { // move through the list until the last value, which points to null
				current = current.next; // move to next link
			}
			current.next = newName; // once we've found the link that points to null, point it to the string instead
			newName.next = null; // update the new link to point to null
			size++; // keep a counter for how many links are in the stack
		} else { //if the queue is empty, this sets the first value
			Link newName = new Link(name); // create a new link with the information from the string
			newName.next = first; // update old first
			first = newName; // new can is first value
			size++;	//make sure to increment the size
		}
	}
	/** called by the public method dequeue() to remove the first value of the queue
	 * @return the value of the removed string
	 */
	private Link remove() {
		if (!isEmpty()) { // if the list is not empty
			Link temp = first; //set the temp variable equal to the first value
			first = first.next; //set the new first value 
			System.out.print("Removed from roster: "); //print to console so that I can see exactly which string is being removed
			temp.displayLink(); //the toString() of the value
			size--; //decrement size
			return temp;
		}
		else {
			System.out.println("The list is empty. Nothing to delete.");
			return null;
		}
	}
	/**
	 *  called by the public method peek() to print the first value in the queue
	 */
	private void lookylooky(){
		if (!isEmpty()) {
			Link current = first; //I'm actually not sure if I have to do this, or if I can just use first
			System.out.print("Peeking: "); //put this so you can read that it's a peek() easier
			current.displayLink();
		}
		else {
			System.out.println("The queue is empty, nothing to peek at");
		}
	}
	/**
	 * called by public method printQueue(), display the toString() of each value of the queue 
	 */
	private void display(){
		System.out.println("Roster: ");
		Link current = first;
		if (!isEmpty()) {	//make sure the stack is not empty
			while (current != null) {
				current.displayLink();	//print the name at current
				current = current.next;	//move on to the next name
			}
		} else {
			System.out.println("Linked list is empty, nothing to display.");	//if the stack is empty, display this message
		}
	}
	/**
	 * called by public method queueSize() it prints an integer of how many values are in the queue
	 */
	private void size() {
		System.out.println("There are " + size + " links in the Queue.");
	}
}
