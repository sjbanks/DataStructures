
/** This class does the calculations for a rectangle
 * @author Steven Banks
 *
 */
public class Rectangle implements Measurements {
	
	//declare some more variables
	private double l;
	private double w;
	
	/**
	 * @param l the length of a rectangle
	 * @param w the width of a rectangle
	 */
	public Rectangle(double l, double w) {
		this.l = l;
		this.w = w;
		area(l, w);
		perimeter(l, w);
	}

	/* (non-Javadoc)
	 * @see Measurements#area(double)
	 */
	@Override
	public double area(double a) {
		return 0;
	}

	/* (non-Javadoc)
	 * @see Measurements#area(double, double)
	 */
	@Override
	public double area(double l, double w) {
		double area = l * w;
		return area;
	}

	/* (non-Javadoc)
	 * @see Measurements#perimeter(double)
	 */
	@Override
	public double perimeter(double a) {
		return 0;
	}

	/* (non-Javadoc)
	 * @see Measurements#perimeter(double, double)
	 */
	@Override
	public double perimeter(double l, double w) {
		double perimeter = (2 * l) + (2 * w);
		return perimeter;
	}
}
