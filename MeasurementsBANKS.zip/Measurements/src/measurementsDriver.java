import java.util.Scanner;

/** This driver file uses nested loops to keep asking for input until a user enters a sentinel value. It computes the area and perimeter of
 * either a square or a rectangle
 * @author Steven Banks
 *
 */
public class measurementsDriver {

	public static void main(String[] args) {
		
		//declare some variables
		Scanner in = new Scanner(System.in);
		String userShape;
		String keepGoing;
		double side;
		double l;
		double w;
		boolean done = true;
		
		//The loop is designed to continue prompting you for input until you are done with it, at which point the sentinel value will terminate the loop
		do { System.out.print("Are you viewing a square or a rectangle? ");
			userShape = in.next();
			if (userShape.equalsIgnoreCase("square")) {
				System.out.print("What is the value of the side of a square? ");
				side = in.nextDouble();
				Square sqr = new Square(side);
				System.out.print("The area of the square is: " + sqr.area(side) + "\n");
				System.out.print("The perimeter of the square is: " + sqr.perimeter(side) + "\n");
				System.out.print("Would you like to enter another shape? Yes to conintue, no to stop. ");
				keepGoing = in.next();
				if (keepGoing.equalsIgnoreCase("yes")) {
					done = false;
				}
				else { System.out.println("Goodbye!");
					done = true;
				
				}
			}
			else if (userShape.equalsIgnoreCase("rectangle")) {
				System.out.print("What is the value of the length of a rectangle? ");
				l = in.nextDouble();
				System.out.print("What is the value of the width of a rectangle? ");
				w = in.nextDouble();
				Rectangle rec = new Rectangle(l, w);
				System.out.println("The area of the rectangle is: " + rec.area(l, w));
				System.out.println("The perimeter of the rectangle is: " + rec.perimeter(l, w));
				System.out.print("Would you like to enter another shape? Yes to continue, no to stop. " );
				keepGoing = in.next();
				if (keepGoing.equalsIgnoreCase("yes")) {
					done = false;
				}
				else { System.out.print("Goodbye!");
					done = true;
				}
			}
			else {
				System.out.print("Please enter a valid input. If you wish to continue type yes. If you wish to exit, type no. ");
				userShape = in.next();
				if (userShape.equalsIgnoreCase("no")) {
					System.out.println("Goodbye!");
					done = true;
				}
				else if(userShape.equalsIgnoreCase("yes")) {
					done = false;
				}
			}
		}
		while(!done); 
}
}
