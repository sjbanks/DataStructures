
/** an interface for finding area and perimeter of certain shapes
 * @author Steven Banks
 *
 */
public interface Measurements {
	
	
	//declare method signatures
	public double area(double a);
	public double area(double l, double w);
	public double perimeter(double a);
	public double perimeter(double l, double w);
	

}
