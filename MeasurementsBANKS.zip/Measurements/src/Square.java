
/**This class does all the calculations for a square
 * @author Steven Banks
 *
 */
public class Square implements Measurements {
	//declare a variable to store values
	double side;
	
	/**
	 * @param side	the value of a side of a square
	 */
	public Square(double side) {
		this.side = side;
		perimeter(side);
		area(side);
	}
	
	/**
	 * @return the value of the side
	 */
	@SuppressWarnings("unused")
	private double getSide() {
		return side;
	}
	/**
	 * @param side the side to set
	 */
	private void setSide(double side) {
		this.side = side;
	}
	/* (non-Javadoc)
	 * @see Measurements#area(double)
	 */
	@Override
	public double area(double a) {
		double area = Math.pow(a, 2);
		return area;
	}
	/* (non-Javadoc)
	 * @see Measurements#perimeter(double)
	 */
	@Override
	public double perimeter(double a) {
		double perimeter = 4 * a;
		return perimeter;
	}
	/* (non-Javadoc)
	 * @see Measurements#area(double, double)
	 */
	@Override
	public double area(double l, double w) {
		return 0;
	}
	/* (non-Javadoc)
	 * @see Measurements#perimeter(double, double)
	 */
	@Override
	public double perimeter(double l, double w) {
		return 0;
	}
	

}
