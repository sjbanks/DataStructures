
/**This is the driver file for my queue class
 * @author Steven Banks
 *
 */
public class QueueDriverBANKS {

	public static void main(String[] args) throws Queue.Overflow, Queue.Underflow {
		
		//Create a new queue with default size
		Queue newQue = new Queue();
		//add some elements to the queue
		newQue.enqueue("Dog");
		newQue.enqueue("Cat");
		newQue.enqueue("Mouse");
		newQue.enqueue("Pig");
		newQue.enqueue("Bird");
		
		//let's print the queue
		newQue.print();
		System.out.println();
		
		//print the size; should be 5
		System.out.println("The queue size is: " +newQue.size());
		System.out.println("There are " + newQue.elements() + " elements in the queue.\n");
		
		//try to add a sixth element, expect to throw my Overflow exception
		//newQue.enqueue("puppy"); //Hurray, it did throw my exception!
		
		//and now we try to dequeue and hope the wraparound worked!
		System.out.println(newQue.dequeue());
		System.out.println(newQue.dequeue() + "\n");
		
		System.out.println("The queue size is : " + newQue.size());
		System.out.println("There are " + newQue.elements() + " elements in the queue.");
		
		System.out.println(newQue.dequeue());
		System.out.println(newQue.peek());
		System.out.println(newQue.dequeue());
		System.out.println(newQue.dequeue());
		System.out.println(newQue.size());
		System.out.println(newQue.isEmpty());
		
		//fill the queue with some data
		newQue.enqueue("Rose Hair Tarantula");
		newQue.enqueue("Orange Baboon Tarantula");	//this is actually the tarantula in the Java book from last semester!
		newQue.enqueue("Cobalt Blue Tarantula");
		newQue.enqueue("Trinidad Chevron Tarantla");
		newQue.enqueue("Indian Ghost Ornamental Tarantula");
		
		//now to test the size of the queue, as well as the number of items it contains
		System.out.println("The size of this queue is : " + newQue.size());
		System.out.println("There are " + newQue.elements() + " elements in this queue.\n");
		System.out.println(newQue.peek());	//should print rose hair
		
		//empty 4 elements
		System.out.println(newQue.dequeue());
		System.out.println(newQue.dequeue());
		System.out.println(newQue.dequeue());
		System.out.println(newQue.dequeue());
		System.out.println(newQue.peek());	//should print ghost ornamental
		
		//now to fill it back up
		newQue.enqueue("Mexican Red-Knee Tarantula");
		newQue.enqueue("Arizona Brown/Texas Tan Tarantula");
		newQue.enqueue("Pink-Toe Tarantula");
		newQue.enqueue("Green-Bottle Blue Tarantula"); //should be full now
		
		//test if the queue is full
		if (newQue.isFull()) {
			System.out.println("This queue is full!");	//should print this string
		}
		else {
			System.out.println("BANKS done messed up.");	//no
		}
		
		//retest size and nItems
		System.out.println("The size of this queue is : " + newQue.size());
		System.out.println("There are " + newQue.elements() + " elements in this queue.\n");
		
		newQue.peek();	//make sure no items have shifted
		
		//now I'm going to empty the queue
		System.out.println(newQue.dequeue());
		System.out.println(newQue.dequeue());
		System.out.println(newQue.dequeue());
		System.out.println(newQue.dequeue());
		System.out.println(newQue.dequeue());
		System.out.println();
		
		//test if empty
		if(newQue.isEmpty()) {
			System.out.println("This queue is empty!");
		}
		else {
			System.out.println("Tsk tsk");
		}
		
		//let's test the underflow exception
		System.out.println(newQue.dequeue());
		
	}

}
