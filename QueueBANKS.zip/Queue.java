
/**This class creates a queue that accepts strings and deals with wraparound
 * @author Steven Banks
 *
 */
public class Queue {

	//declare some variables
	private int queueSize = 5;	//default size of 5
	private int front;	
	private int rear;
	private int nItems;		//to track the number of strings in the array
	private String[] queArray;
	
	/**
	 * default constructor sets the size of the queue to 5
	 */
	public Queue() {
		queue(queueSize);
	}
	/**
	 * @param size lets user set the size of the queue
	 */
	public Queue(int size) {
		queue(size);
	}
	
	/**
	 * @return the size of the queue
	 */
	public int getQueueSize() {
		return queueSize;
	}
	/**
	 * @param size set the size of the queue
	 */
	public void setQueueSize(int size) {
		this.queueSize = size;
	}
	/**
	 * @return the front of the queue
	 */
	public int getFront() {
		return front;
	}
	/**
	 * @param front set the front of the queue
	 */
	public void setFront(int front) {
		this.front = front;
	}
	/**
	 * @return the rear of the queue
	 */
	public int getRear() {
		return rear;
	}
	/**
	 * @param rear set the rear of the queue
	 */
	public void setRear(int rear) {
		this.rear = rear;
	}
	/**
	 * @return nItems how many items are in the queue
	 */
	public int getnItems() {
		return nItems;
	}
	/**
	 * @param nItems set the number of items in the queue
	 */
	public void setnItems(int nItems) {
		this.nItems = nItems;
	}
	
	//public methods
	/**
	 * @return true if queue is full
	 */
	public boolean isFull() {
		return (nItems == queueSize);	
	}
	/**
	 * @return	true if queue is empty
	 */
	public boolean isEmpty() {
		return (nItems == 0);	
	}
	/**
	 * @param animal a string 
	 * @throws Overflow
	 */
	public void enqueue(String animal) throws Overflow{
		add(animal);
	}
	/**
	 * @return the value that was removed
	 * @throws Underflow
	 */
	public String dequeue() throws Underflow{
		return remove() + " was removed from queue.";
	}
	/**
	 * @return the size of the queue
	 */
	public int size() {
		return queueSize;
	}
	/**
	 * @return the number of elements in the queue
	 */
	public int elements() {
		return nItems;
	}
	/**
	 * calls a private helper method to print the queue from the front
	 */
	public void print() {
		printQueue();
	}
	/**
	 * @return the front value of the queue
	 */
	public String peek() {
		return lookylooky();
	}
	
	
	//private helper methods for data hiding
	/**
	 * @param size of the queArray
	 * @return	a new empty queue
	 */
	private String[] queue(int size){
		front = 0;
		rear = -1;
		nItems = 0;
		return queArray = new String[size];
	}
	/**
	 * @param animal is the string passed into the method
	 */
	private void add(String animal) throws Overflow{
		if (!isFull()) {
			if (rear == (queueSize - 1)) {	//check to see if the rear is at the last element
				rear = -1;	//wrap it around to the 0 element
			}
			queArray[++rear] = animal; //increment rear and then set it equal to animal String
			nItems++;	//increment number of items in the queue
		}
		else {
			throw new Overflow("Overflow! Queue is full!");
		}
	}
	/**
	 * @return the string value of the front of the queue, then increment the front
	 * @throws Underflow
	 */
	private String remove() throws Underflow {
		if (!isEmpty()) {	//make sure the string isn't empty
			String temp = queArray[front++];  
			if (front == queueSize) {
				front = 0;
			}
			nItems--;
			return temp;
		}
		else {
			throw new Underflow("Underflow! Queue is empty!");
		}
	}
	/**
	 * @return the front string value in the queue
	 */
	private String lookylooky() {
		return queArray[front];
	}
	/**
	 * will print the remaining elements in the queue beginning with the front
	 */
	private void printQueue() {
		for(int i = front; i < nItems; i++) {
			System.out.println(queArray[i]);
		}
	}
	
	/**These are custom exceptions 
	 * @author Steven Banks
	 *
	 */
	public class Overflow extends Exception{
		/**
		 * I have no idea what this is about 
		 */
		private static final long serialVersionUID = 1L;

		public Overflow(String overflow) {
		}
	}
	public class Underflow extends Exception{
		/**
		 * I have no idea what this is about
		 */
		private static final long serialVersionUID = 1L;

		public Underflow(String underflow) {			
		}
	}
}
