
/**	This subclass is not abstract, and will implement the methods from the abstract class Cycle
 * @author Steven Banks
 *	
 */
public class Bicycle extends Cycle {

	//Declare a new variable
	private int inflatedTires;
	
	/**
	 * default
	 */
	Bicycle (){
		
	}
	
	/**
	 * @param tires the number of tires
	 */
	Bicycle (int tires){
		this.setNumberOfTires(tires);
		setInflatedTires(2);
	}
	
	/**
	 * @param tires the number of tires 
	 * @param flats the number of flats
	 */
	Bicycle (int tires, int flats){
		this.setNumberOfTires(tires);
		this.setNumberOfFlats(flats);
		setInflatedTires(2);
	}
	
	/**
	 * @return the inflatedTires
	 */
	private int getInflatedTires() {
		return inflatedTires;
	}

	/**
	 * @param inflatedTires the inflatedTires to set
	 */
	private void setInflatedTires(int inflatedTires) {
		this.inflatedTires = inflatedTires;
	}

	/* (non-Javadoc)
	 * @see Cycle#ride()
	 */
	@Override
	public void ride() {
		if (inflatedTires == 2) {
			System.out.println("You ride your bike forward!");
		}
		else {
			System.out.println("Might wanna change your tires first.");
		}
	}

	/* (non-Javadoc)
	 * @see Cycle#stop()
	 */
	@Override
	public void stop() {
		System.out.println("You hit the brakes and stop!");
	}

	/* (non-Javadoc)
	 * @see Cycle#wheelie()
	 */
	@Override
	public void wheelie() {
		if (inflatedTires == 2) {
			System.out.println("You pop a sweet wheelie!");
		}
		else {
			System.out.println("Might wanna change your tires first.");
		}
	}
	
	/* (non-Javadoc)
	 * @see Cycle#popATire()
	 */
	@Override
	public void popATire() {
		if (getInflatedTires() <= 2 && getInflatedTires() >= 1) {
			System.out.println("Whoops! You popped a tire! Time to fix that.");
			numberOfFlats ++;
			inflatedTires--;
		}
		else {
			System.out.println("You gotta change the tire before you can pop another one! Why would you wanna do that anyway?");
		}
	}
	
	/* (non-Javadoc)
	 * @see Cycle#changeTire()
	 */
	@Override
	public void changeTire() {
		if (this.getInflatedTires() < 2 && this.getInflatedTires() >= 0) {
			System.out.println("You changed a tire.");
			inflatedTires++;
		}
		else if (this.getInflatedTires() == 2) {
			System.out.println("Your tires are already good!");
		}	
	}
	
	/* (non-Javadoc)
	 * @see Cycle#bikeStatus()
	 */
	@Override
	public void bikeStatus() {
		System.out.println("You have " + inflatedTires + " inflated tires. You've had " + getNumberOfFlats() + " total flats.");
	}

}
