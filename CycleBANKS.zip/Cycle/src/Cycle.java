
/**
 * @author Steven Banks
 *	This abstract class will be used in other classes to share basic methods
 */
public abstract class Cycle {

	//Declare fields
	int numberOfTires;
	int numberOfFlats;
	
	/**
	 * @return the numberOfTires
	 */
	public int getNumberOfTires() {
		return numberOfTires;
	}
	/**
	 * @param numberOfTires the numberOfTires to set
	 */
	public void setNumberOfTires(int numberOfTires) {
		this.numberOfTires = numberOfTires;
	}
	/**
	 * @return the numberOfFlats
	 */
	public int getNumberOfFlats() {
		return numberOfFlats;
	}
	/**
	 * @param numberOfFlats the numberOfFlats to set
	 */
	public void setNumberOfFlats(int numberOfFlats) {
		this.numberOfFlats = numberOfFlats;
	}
	
	//abstract methods without a body
		abstract public void ride();
		abstract public void stop();
		abstract public void wheelie();
		abstract public void popATire();
		abstract public void changeTire();
		abstract public void bikeStatus();
}
