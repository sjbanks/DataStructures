
/** This is the tester for the cycle classes
 * @author Steven Banks
 *
 */
public class CycleDriver {

	public static void main(String[] args) {
		
		//Making some bikes
		Bicycle roadWarrior = new Bicycle(2, 0);
		Cycle acmeBike = new Bicycle();
		acmeBike.setNumberOfFlats(1);
		acmeBike.setNumberOfTires(2);
		Cycle mongoose = new Bicycle(2);
		mongoose.setNumberOfFlats(4);
		
		//let's do some testing
		//roadWarrior bike should ride smoothly, no problem
		roadWarrior.ride();
		roadWarrior.stop();
		roadWarrior.ride();
		roadWarrior.wheelie();
		roadWarrior.popATire();
		//expecting to have 1 inflated tire
		roadWarrior.bikeStatus();
		roadWarrior.changeTire();
		//should ride again without problem
		roadWarrior.ride();
		//expecting number of flats to go up
		roadWarrior.bikeStatus();
		//to help separate the bike output
		System.out.println();
		
		//should show it's had 1 flat before
		acmeBike.bikeStatus();
		//should display a message saying you have to fix the tires before you can pop more
		acmeBike.popATire();
		//Should display a message saying you can't ride 
		acmeBike.ride();
		acmeBike.changeTire();
		//should again not let you ride without 2 inflated tires
		acmeBike.ride();
		acmeBike.changeTire();
		//should ride just fine
		acmeBike.ride();
		acmeBike.stop();
		//number of flats should have gone up by 2 since the first status check
		acmeBike.bikeStatus();
		//to help separate the bike output
		System.out.println();
		
		//should show a history of 4 flat tires
		mongoose.bikeStatus();
		mongoose.wheelie();
		mongoose.popATire();
		mongoose.changeTire();
		mongoose.ride();
		mongoose.stop();
		//making sure number of flats incremented
		mongoose.bikeStatus();
		
	}

}

