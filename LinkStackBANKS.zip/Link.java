/**This class creates the links in the linked list
 * @author Steven Banks
 *
 */
public class Link {

	//declare variables 
	public Clothing clothing;
	public Link next;
	
	/**
	 * @param clothing accepts a user-created article of clothing
	 */
	public Link(Clothing clothing) {
		this.clothing = clothing;	//set the global variable to the argument passed in
	}
	
	/**
	 * @return	the value of the next link
	 */
	public Link getNext() {
		return next;
	}
	/**
	 * @param next allows you to manually set the value of the next link
	 */
	public void setNext(Link next) {
		this.next = next;
	}

	/**
	 * toString() that helps the printStack() method
	 */
	public void displayLink() {
		System.out.println(clothing.toString());
	}
}
