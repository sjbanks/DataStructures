
/**This is the driver file for the linked list stack
 * @author Steven BANKS
 *
 */
public class StackDriver {

	public static void main(String[] args) {
		
		//add some clothes to start this puppy off
		Clothing purpleCardigan = new Shirt("Cardigan", "S", "Purple");
		Clothing blueTShirt = new Shirt("T-Shirt", "M", "Blue");
		Clothing uglyXmas = new Shirt("Ugly Christmas Sweater", "L", "Yuck");		
		Stack newStack = new Stack();	//create a new stack
		newStack.push(purpleCardigan);	//start pushing the items onto the stack
		newStack.push(blueTShirt);
		newStack.push(uglyXmas);	//should be at 3 items in the stack
		newStack.peek();	//should return the top value, the xmas sweater
		newStack.printStack();	//Prints the stack, though not in reverse order
		newStack.size();	//should print that there are 3 links in stack
		System.out.print("--------------------------------------\n");	//just trying to make it easier to read
		
		//create some other articles of clothing
		Clothing pinkSocks = new Socks("Small", "Pink", true);
		Clothing slacks = new Pants("Small", "Black");
		Clothing blueJeans = new Pants("Medium", "Denim");		
		newStack.push(pinkSocks);	//push items onto stack
		newStack.push(slacks);
		newStack.push(blueJeans);		
		newStack.size();	//there be 6 items now
		newStack.peek(); //should return the bluejeans
		newStack.printStack(); //should print all 6 items
		System.out.print("--------------------------------------\n");	//just trying to make it easier to read
		
		newStack.pop();
		newStack.pop(); //pop the two pants off
		newStack.size(); //should be 4
		newStack.printStack(); 
		System.out.print("--------------------------------------\n");	//just trying to make it easier to read
		
		newStack.pop();
		newStack.pop();
		newStack.pop();
		newStack.pop(); //should be empty now
		newStack.pop(); //should display a message saying the stack is empty
		newStack.size();//should return 0
		newStack.peek();//should display message saying the stack is empty
		System.out.println(newStack.isEmpty()); //let's check to make sure the stack is empty
		System.out.print("--------------------------------------\n");	//just trying to make it easier to read
	}

}
