
/**This is the program that creates the stack and implements it's methods
 * @author Steven BANKS
 *
 */
public class Stack {

	private Link first; // to set the first value of the stack
	private int size; // Will count the amount of links in my stack

	/**
	 * sets the first value to default null, until links are added
	 * set the size = to 1 so that it correctly increments and decrements, according to how I've coded it
	 */
	public Stack() {
		first = null;
		size = 1;
	}
	
	/**
	 * @return true if the linked list is empty
	 */
	public boolean isEmpty() {
		return (first == null);
	}

	/**
	 * @param clothing takes a user created clothing and adds it to the stack
	 * Also this increments the size integer to keep track of how many links are in the stack           
	 */
	public void push(Clothing clothing) {
		if (!isEmpty()) {
			Link newClothing = new Link(clothing); // create a new link with the information from the clothing
			Link current = first; // basically a pointer to move through the list so far
			while (current.next != null) { // move through the list until the last value, which points to null
				current = current.next; // move to next link
			}
			current.next = newClothing; // once we've found the link that points to null, point it to the new clothing
										// instead
			newClothing.next = null; // update the new link to point to null
			size++; // keep a counter for how many links are in the stack
		} else {
			Link newClothing = new Link(clothing); // create a new link with the information from the can
			newClothing.next = first; // update old first
			first = newClothing; // new can is first value
		}
	}

	/**
	 * Pop the top of the stack off, and decrement the size integer 
	 * @return the value of the deleted link
	 */
	public Link pop() {
		if (!isEmpty()) { // if the list is not empty
			Link current = first;
			Link previous = first;
			if (first.next == null) {	//check to see if there's only one remaining element
				first = null;	//set the stack to empty
			}
			while (current.next != null) { // while current.next does not equal null
				previous = current; // update previous
				current = current.next; // update current
			}
			System.out.println(current.clothing.toString() + " has been removed from the stack.");
			size--; // decrement the stack size
			previous.next = current.next; // remove the pointer from current
			return current;
		} else {
			System.out.println("Stack is empty, nothing to delete."); // instead of an exception, display this
			return null;
		}
	}

	/**
	 * @return	the value of the link on top of the stack
	 */
	public Link peek() {
		if (!isEmpty()) {
			Link current = first;
			while (current.next != null) {	
				current = current.next;	//move through the stack to the top value
			}
			System.out.print("Peeking: ");
			current.displayLink();	//this displays the toString for the article of clothing
			return current;
		} else {
			System.out.println("The stack is empty, nothing to peek.");	//display if the stack is empty
			return null;
		}
	}
	/**
	 * prints the stack by using a toString() for each article
	 */
	public void printStack() {
		System.out.println("List O' Clothes: ");
		Link current = first;
		if (!isEmpty()) {	//make sure the stack is not emtpy
			while (current != null) {
				current.displayLink();	//toString() value of the clothing
				current = current.next;	//move on to the next article
			}
		} else {
			System.out.println("Linked list is empty, nothing to display.");	//if the stack is empty, display this message
		}
	}
	/**
	 * Displays the integer value of how many links are in the stack, is incremented and decremented through the push and pop methods
	 */
	public void size() {
		System.out.println("There are " + size + " links in the stack.");
	}
}
