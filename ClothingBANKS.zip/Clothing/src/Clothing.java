
/**This program creates articles of clothing
 * @author sjbanks
 *
 */
public class Clothing {
	//Steven Banks
	
	private String size;
	private String color;
	
	/**
	 * default constructor
	 */
	public Clothing() {
		
	}
	
	/**
	 * @param s		sets size of the clothing
	 * @param c		sets color of the clothing
	 */
	public Clothing(String s, String c) {
		setSize(s);
		setColor(c);
	}
	
	/**
	 * @return		the size of the article of clothing
	 */
	public String getSize() {
		return size;
	}
	/**
	 * @param size	sets the size of the article of clothing
	 */
	public void setSize(String size) {
		this.size = size;
	}
	/**
	 * @return		the color of the article of clothing
	 */
	public String getColor() {
		return color;
	}
	/**
	 * @param color	sets the color of the article of clothing
	 */
	public void setColor(String color) {
		this.color = color;
	}
	
	@Override
	public String toString() {
		return "Clothing [size=" + size + ", color=" + color + "]";
	}
}
