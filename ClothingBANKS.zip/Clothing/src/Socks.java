
/**This sublass socks extends the superclass Clothing
 * @author sjbanks
 *
 */
public class Socks extends Clothing{
	//Steven Banks
	
	private boolean pair = true; //set the boolean to true as default

	/**
	 * 
	 */
	public Socks() {
		
	}
	
	/**
	 * @param s		sets the size of the socks
	 * @param c		sets the color of the socks
	 */
	public Socks(String s, String c) {
		setSize(s);
		setColor(c);
	}
	
	/**
	 * @param s			sets the size of the socks
	 * @param c			sets the color of the socks
	 * @param isPair	sets true or false if there's a pair of socks
	 */
	public Socks(String s, String c, boolean isPair) {
		setSize(s);
		setColor(c);
		setPair(isPair);
	}
	
	/**
	 * @param isPair	if the socks are a pair or not
	 */
	public Socks(boolean isPair) {
		setPair(isPair);
	}
	
	/**
	 * @return		if the socks are a pair
	 */
	public boolean isPair() {
		return pair;
	}
	/**
	 * @param pair		sets if the socks are a pair
	 */
	public void setPair(boolean pair) {
		this.pair = pair;
	}
	
	@Override
	public String toString() {
		return "Socks [pair=" + pair + ", size=" + getSize() + ", color=" + getColor() + "]";
	}
}
