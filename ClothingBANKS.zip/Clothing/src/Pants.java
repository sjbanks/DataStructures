
/**This subclass pants extends the superclass Clothing
 * @author sjbanks
 *
 */
public class Pants extends Clothing{
	//Steven Banks
	
	/**
	 * 
	 */
	public Pants() {
		
	}
	
	/**
	 * @param size		set the size of the pants
	 * @param color		set the color of the pants
	 */
	public Pants(String size, String color) {
		setSize(size);
		setColor(color);
	}

}
