
/**This subclass shirt extends the clothing superclass
 * @author sjbanks
 *
 */
public class Shirt extends Clothing{
	//Steven Banks
	
	private String style;
	
	/**
	 * default
	 */
	public Shirt() {
		
	}
	
	/**
	 * @param st		sets the style of the shirt
	 */
	public Shirt(String st) {
		setStyle(st);
	}
	
	/**
	 * @param size		set the size of the shirt
	 * @param color		sets the color
	 */
	public Shirt(String size, String color) {
		if(size.equals("S") || size.equals("M") || size.equals("L") || size.equals("XL")) {
			setSize(size); 
		}
		else {
			setSize(null);
		}
		setColor(color);
	}
	
	/**
	 * @param style		sets the style of the shirt
	 * @param size		sets the size of the shirt
	 * @param color		sets the color of the shirt
	 */
	public Shirt(String style, String size, String color) {
		setStyle(style);
		if(size.equals("S") || size.equals("M") || size.equals("L") || size.equals("XL")) {
			setSize(size); 
		}
		else {
			setSize(null);
		}
		setColor(color);
	}
	
	/**
	 * @return		the style of shirt
	 */
	public String getStyle() {
		return style;
	}
	/**
	 * @param style	set the style of shirt
	 */
	public void setStyle(String style) {
		this.style = style;
	}
	
	@Override
	public String toString() {
		return "Shirt [style=" + style + ", size=" + getSize() + ", color=" + getColor() + "]";
	}
}
