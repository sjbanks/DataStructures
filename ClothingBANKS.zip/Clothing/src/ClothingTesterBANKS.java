
/**This is the driver file for the Clothing class
 * @author sjbanks
 *
 */
public class ClothingTesterBANKS {
	//Steven Banks
	public static void main(String[] args) {
		
		//Testing the super class
		Clothing suit = new Clothing();
		Clothing jersey = new Clothing("medium", "blue");
		Clothing sweatSuit = new Clothing("Large", "Grey");
		System.out.println("clothing 1: " + suit);
		System.out.println("clothing 2: " + jersey);
		System.out.println("Clothing 3: " + sweatSuit);
		System.out.println();
		
		//testing the shirt class
		Clothing blueShirt = new Shirt("medium", "blue"); //size should be null
		Shirt pinkShirt = new Shirt("Short Sleeves");
		Shirt yellowShirt = new Shirt("Hoodie", "XL", "Yellow");
		Clothing redShirt = new Shirt();
		pinkShirt.setColor("Pink");
		pinkShirt.setSize("M");
		((Shirt) redShirt).setStyle("Doomed");
		redShirt.setSize("S");
		redShirt.setColor("Red");
		System.out.println("blueShirt " + blueShirt);
		System.out.println("pinkShirt " + pinkShirt);
		System.out.println("yellowShirt " + yellowShirt);
		System.out.println("redShirt " + redShirt);
		System.out.println();
		
		//testing the pants class
		Pants blackPants = new Pants();
		blackPants.setColor("Black");
		blackPants.setSize("M");
		Pants tanPants = new Pants("XXL", "Tan");
		System.out.println("blackPants " + blackPants);
		System.out.println("tanPants " + tanPants);
		System.out.println();
		
		//testing socks class
		Clothing purpleSocks = new Socks("9-10", "Purple");
		Socks greenSock = new Socks("7-8", "Green", false);
		Socks blackSocks = new Socks("Enormous", "Black");
		Socks whiteSocks = new Socks(false);
		whiteSocks.setSize("10-11");
		whiteSocks.setColor("White");
		System.out.println("purpleSocks " + purpleSocks);
		System.out.println("greenSocks " + greenSock);
		System.out.println("blackSocks " + blackSocks);
		System.out.println("whiteSocks " + whiteSocks);

	}

}
