
/**This class creates the links in the linked list
 * @author Steven Banks
 *
 */
public class Link {

	//declare variables 
	public Can Can;
	public Link next;
	
	/**
	 * @param can	takes an object of the Can Class
	 */
	public Link(Can can) {
		Can = can;	//set the global variable to the argument passed in
	}
	
	/**
	 * @return the next link
	 */
	public Link getNext() {
		return next;
	}

	/**
	 * @param next set the next link
	 */
	public void setNext(Link next) {
		this.next = next;
	}

	/**
	 * Displays a single cans toString, whichever one was the last created. 
	 */
	public void displayLink() {
		System.out.println(Can.toString());
	}
}
