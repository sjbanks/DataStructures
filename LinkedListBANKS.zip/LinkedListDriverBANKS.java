
/**Driver file for LinkedList class, with lots of testing
 * @author Steven Banks
 *
 */
public class LinkedListDriverBANKS {

	public static void main(String[] args) {
		//Create my first set of variables with varied characteristics
		Can beefSupreme = new Can("Bovine Basics", "Beef Supreme", 18, 2.99);
		Can chickenNoodle = new Can("Campbell's Condensed", "Chicken Noddle Soup", 12, 1.99);
		Can chickenBroth = new Can("Hy-Vee", "Chicken Broth", 12, 2.99);
		Can beer = new Can("Anheiser-Busch", "Busch Light", 12, 0.99);
		Can pumpkinPuree = new Can("Mrs. CookingPersonality", "Pumpkin Puree", 12, 4.99);
		
		//new make a new linked list and add all cans created above
		LinkedList firstList = new LinkedList();
		firstList.addFirst(beefSupreme);
		firstList.addFirst(chickenNoodle);
		firstList.addFirst(chickenBroth);
		firstList.addFirst(beer);
		firstList.addFirst(pumpkinPuree);
		
		firstList.displayList(); //should be in reverse order of above, starting with pumpkin puree
		
		Can chowda = new Can("Delicious Delightful Dainty", "Cheezy Chowda", 14.5, 4.50);	//new can
		
		firstList.addLast(chowda); //should add to the end of the list, coming after beef supreme
		
		firstList.displayList(); //should display 6 items in the list
		
		Can worms = new Can("Pandora's Box Store", "Can of Worms", 24, 999.99); //that's one expensive can of worms
		
		firstList.addFirst(worms); //check to make sure everything is in the correct order
		firstList.displayList(); //can of worms should now be first, with chowda last
		
		firstList.find("Hy-Vee"); //should return the toString() for chickenBroth can
		
		firstList.delete(chickenNoodle);	//should delete Campbell's condensed chicken noodle soup
		firstList.displayList(); //make sure chicken noodle was deleted from linked list
		
		firstList.deleteFirst();
		firstList.deleteFirst(); //should remove can of worms and pumpkin puree
		
		firstList.displayList(); //check to make sure both were deleted
		
		firstList.deleteFirst();
		firstList.deleteFirst();
		firstList.deleteFirst();
		firstList.deleteFirst(); //should be an empty linked list now
		
		firstList.displayList(); //should return that the list is empty
		
		//Create one more linked list for good measure
		Can sugar = new Can("Professor Utonium", "Sugar", 12, 0.00);
		Can spice = new Can("Professor Utonium", "Spice", 12, 0.00);
		Can everythingNice = new Can("Professor Utonium", "Everything Nice", 12, 0.00);
		Can chemicalX = new Can("Professor Utonium", "CHEMICAL X", 12, 0.00);
		//add all the ingredients to the mixture
		LinkedList secondList = new LinkedList();
		secondList.addFirst(sugar);
		secondList.addLast(spice);
		secondList.addLast(everythingNice);
		
		secondList.displayList();	//check it out, make sure it's printing in correct order
		
		secondList.addLast(chemicalX);	//OOPS!!!
		secondList.displayList();	//What have we added to this mixture?
		secondList.combine(sugar, spice, everythingNice, chemicalX);	//Uh oh!
		
		secondList.delete(everythingNice);	//should remove only Everything nice
		secondList.displayList();	//display to make sure the value has been properly removed
		secondList.delete(sugar);	//now delete sugar
		secondList.displayList();	//should be spice, and chemical X left
		secondList.deleteFirst();	
		secondList.deleteFirst();	//empty list
		
		secondList.displayList();	//make sure it displays that the list is empty
		
	}

}
