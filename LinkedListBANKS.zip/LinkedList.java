
/**This is the linkedList class 
 * @author Steven Banks
 *
 */
public class LinkedList {

	private Link first;	//to set the first value of the linked list
	
	/**
	 * sets the first value to default null, until links are added
	 */
	public LinkedList() {
		first = null;
	}
	
	/**
	 * @return true if the linked list is empty
	 */
	public boolean isEmpty() {
		return (first == null);
	}
	/**
	 * @param can takes a user created Can and adds it as the first value in a linked list
	 */
	public void addFirst(Can can) {
		Link newCan = new Link(can);	//create a new link with the information from the can
		newCan.next = first;	//update old first
		first = newCan;	//new can is first value
	}
	/**
	 * @param can takes a user created Can and adds it as the last value in a linked list
	 */
	public void addLast(Can can) {
		Link newCan = new Link(can);	//create a new link with the information from the can
		Link current = first;	//basically a pointer to move through the list so far
		while (current.next != null) {	//move through the list until the last value, which points to null
			current = current.next;	//move to next link
		}
		current.next = newCan;	//once we've found the link that points to null, point it to the new can instead
		newCan.next = null;	//update the new link to point to null
	}
	/**
	 * @param canName accepts a String of the company name
	 * @return	the toString() for the can searched for
	 */
	public Link find(String canName) {
		if (!isEmpty()) {	//as long as the list is not empty
			Link current = first;	//pointer 
			while (current.Can.getCompany() != canName) {	//while the currently pointed to Link does not have the company name
				if (current.next == null) {	//if you get to the end of the list, return null
					return null;
				}
				else {
					current = current.next;	//move to next link
				}
			}
			System.out.println(current.Can.toString());	//print the toString() of the can searched for
			return current;
		}
		else {
			System.out.println("The list is empty, there is nothing to search.");
			return null;
		}
	}
	/**
	 * @param can allows user to delete a specific object
	 * @return	the value of the deleted link
	 */
	public Link delete(Can can) {
		if (!isEmpty()) {	//if the list is not empty
			Link current = first;	
			Link previous = first;
			while (current.Can != can) {	//while the current can is not what we intend to delete
				if (current.next == null) {	
					System.out.println("Link not found.");
					return null;
				}
				else {
					previous = current;	//update previous
					current = current.next;	//update current
				}
			}
			if (current == first) {	//if the delete value is first
				first = first.next;	//update the reference of first to point to the next value
			}
			else {
				previous.next = current.next;	//remove the pointer from current
			}
			return current;
		}
		else {
			System.out.println("List is empty, nothing to delete.");
			return null;
		}
	}
	/**Deletes the first link in the list
	 * @return new temporary value for first
	 */
	public Link deleteFirst() {
		if (!isEmpty()) {
			Link temp = first;
			first = first.next;
			return temp;
		}
		else {
			System.out.println("The list is empty. Nothing to delete.");
			return null;
		}
	}
	/**
	 * Displays every value for the current list in order
	 */
	public void displayList() {
		System.out.println("List O' Cans: " );
		Link current = first;
		if (!isEmpty()) {
			while (current != null) {
				current.displayLink();
				current = current.next;
			}
		}
		else {
			System.out.println("Linked list is empty, nothing to display.");
		}
		System.out.println("");
	}
	/**I couldn't help myself!
	 * @param sugar
	 * @param spice
	 * @param everythingNice
	 * @param chemicalX
	 */
	public void combine(Can sugar, Can spice, Can everythingNice, Can chemicalX) {
		System.out.println("Thus the Powerpuff Girls were born!");
		System.out.println("Using their ultra-super-powers\nBlossom\nBubbles\nAnd Buttercup\nHave dedicated their lives to fighting crime and the forces of EVIL!");
	}
}
